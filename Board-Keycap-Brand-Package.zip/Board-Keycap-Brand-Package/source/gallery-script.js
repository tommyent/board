
const colors=['Porcelain','Sage','Blue','Lilac','Graphite'];
function selectColor(color){
 if(!colors.includes(color))throw new Error('Unknown color');
 const path='icons/exports/'+color+'/Board-'+color+'-';
 document.querySelector('#hero-icon').src=path+'Default-1024.png';
 document.querySelector('#hero-icon').alt='Board Keycap app icon in '+color;
 document.querySelector('#selected-color').textContent=color+' / Native Icon Composer';
 document.querySelectorAll('[data-appearance]').forEach(img=>{img.src=path+img.dataset.appearance+'-1024.png';img.alt=color+' '+img.dataset.appearance+' appearance';});
 const logo='logos/Board-Keycap-'+color;
 document.querySelector('#color-logo').src=logo+'-horizontal.svg';
 document.querySelector('#color-logo').alt='Board '+color+' horizontal logo';
 document.querySelector('#color-logo-link').href=logo+'-horizontal.svg';
 document.querySelector('#stacked-logo-link').href=logo+'-stacked.svg';
 document.querySelector('#color-logo-stage').classList.toggle('dark',color==='Graphite');
}
document.querySelectorAll('input[name=color]').forEach(input=>input.addEventListener('change',()=>selectColor(input.value)));
