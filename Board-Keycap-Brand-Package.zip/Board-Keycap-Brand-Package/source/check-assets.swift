import AppKit

let root = URL(fileURLWithPath: CommandLine.arguments[1])
let colors = ["Porcelain", "Sage", "Blue", "Lilac", "Graphite"]
for color in colors {
    let url = root.appendingPathComponent("Xcode/BoardDockIcons/Board-\(color).icns")
    guard let image = NSImage(contentsOf: url) else { fatalError("Cannot load \(color)") }
    precondition(image.isValid && !image.representations.isEmpty, color)
    precondition(image.representations.contains { $0.pixelsWide == 1024 }, "Missing high resolution: \(color)")
}
let menu = NSImage(contentsOf: root.appendingPathComponent("menu-bar/BoardKeycapTemplate.pdf"))!
precondition(menu.isValid && menu.size == NSSize(width: 18, height: 18))
menu.isTemplate = true
precondition(menu.isTemplate)
print("PASS: AppKit loads all five 1024-pixel ICNS resources and the 18-point menu template.")
