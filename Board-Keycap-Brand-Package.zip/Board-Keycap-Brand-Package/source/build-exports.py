"""Export Board's native sources using explicit Apple tool calls; retains build scratch files."""
from pathlib import Path
import json, shutil, subprocess
from PIL import Image
R=Path(__file__).resolve().parents[1]
ICTOOL='/Applications/Xcode-beta.app/Contents/Applications/Icon Composer.app/Contents/Executables/ictool'
ACTOOL='/Applications/Xcode-beta.app/Contents/Developer/usr/bin/actool'
COLORS=['Porcelain','Sage','Blue','Lilac','Graphite']
APPEARANCES=['Default','Dark','ClearLight','ClearDark','TintedLight','TintedDark']
CAT=R/'Xcode/Board.xcassets'; LEG=R/'Xcode/LegacyAppIcons.xcassets'
for cat in [CAT,LEG]:
 cat.mkdir(parents=True,exist_ok=True); (cat/'Contents.json').write_text(json.dumps({'info':{'author':'xcode','version':1}}))
for color in COLORS:
 doc=R/f'icons/native/Board{color}.icon'; out=R/f'icons/exports/{color}'; out.mkdir(parents=True,exist_ok=True)
 for appearance in APPEARANCES:
  for pixels in ([1024,2048] if appearance in ['Default','Dark'] else [1024]):
   subprocess.run([ICTOOL,str(doc),'--export-image','--output-file',str(out/f'Board-{color}-{appearance}-{pixels}.png'),'--platform','macOS','--rendition',appearance,'--width',str(pixels),'--height',str(pixels),'--scale','1','--design-generation','27','--tint-color','0.8','--tint-strength','0.5'],check=True,capture_output=True)
 build=Path('/private/tmp/board-keycap-build')/color; build.mkdir(parents=True,exist_ok=True)
 subprocess.run([ACTOOL,'--compile',str(build),'--platform','macosx','--minimum-deployment-target','13.0','--app-icon',f'Board{color}','--output-partial-info-plist',str(build/'partial-info.plist'),'--output-format','human-readable-text',str(doc)],check=True,capture_output=True)
 decoded=build/'Native.iconset'
 subprocess.run(['/usr/bin/iconutil','-c','iconset',str(build/f'Board{color}.icns'),'-o',str(decoded)],check=True)
 iconset=R/f'icons/legacy/Board-{color}.iconset'; iconset.mkdir(parents=True,exist_ok=True)
 appset=LEG/f'Board{color}Legacy.appiconset'; appset.mkdir(exist_ok=True)
 preview=CAT/f'BoardIcon{color}.imageset'; preview.mkdir(exist_ok=True)
 master=Image.open(out/f'Board-{color}-Default-2048.png').convert('RGBA'); entries=[]
 for size in [16,32,128,256,512]:
  for scale in [1,2]:
   pixels=size*scale; fn=f'icon_{size}x{size}'+('@2x' if scale==2 else '')+'.png'
   native=decoded/fn
   if not native.exists(): native=next((p for p in decoded.glob('*.png') if Image.open(p).width==pixels),None)
   if native: shutil.copyfile(native,iconset/fn)
   else:
    # Native large export, fitted to Apple's observed 80% legacy icon metrics.
    canvas=Image.new('RGBA',(pixels,pixels)); extent=round(pixels*.8); inset=(pixels-extent)//2
    canvas.alpha_composite(master.resize((extent,extent),Image.Resampling.LANCZOS),(inset,inset)); canvas.save(iconset/fn)
   shutil.copyfile(iconset/fn,appset/fn)
   entries.append({'idiom':'mac','size':f'{size}x{size}','scale':f'{scale}x','filename':fn})
 (appset/'Contents.json').write_text(json.dumps({'images':entries,'info':{'author':'xcode','version':1}},indent=2))
 icns=R/f'icons/legacy/Board-{color}.icns'
 subprocess.run(['/usr/bin/iconutil','-c','icns',str(iconset),'-o',str(icns)],check=True)
 subprocess.run(['/usr/bin/iconutil','-c','iconset',str(icns),'-o',str(build/'Roundtrip.iconset')],check=True)
 assert len(list((build/'Roundtrip.iconset').glob('*.png')))==10
 dock=R/'Xcode/BoardDockIcons'; dock.mkdir(exist_ok=True); shutil.copyfile(icns,dock/icns.name)
 shutil.copyfile(iconset/'icon_512x512@2x.png',out/f'Board-{color}-Dock-1024.png')
 previewentries=[]
 for scale,pixels in [(1,512),(2,1024)]:
  fn=f'BoardIcon{color}'+('@2x' if scale==2 else '')+'.png'
  Image.open(out/f'Board-{color}-Dock-1024.png').resize((pixels,pixels),Image.Resampling.LANCZOS).save(preview/fn)
  previewentries.append({'idiom':'mac','scale':f'{scale}x','filename':fn})
 (preview/'Contents.json').write_text(json.dumps({'images':previewentries,'info':{'author':'xcode','version':1}},indent=2))
 digital=R/f'digital/{color}'; digital.mkdir(parents=True,exist_ok=True)
 for pixels in [32,64,180,512]: Image.open(out/f'Board-{color}-Default-1024.png').resize((pixels,pixels),Image.Resampling.LANCZOS).save(digital/f'Board-{color}-{pixels}.png')
 print(color+': native actool compile and full 10-size ICNS roundtrip PASS',flush=True)
for p in R.rglob('Contents.json'):
 for entry in json.loads(p.read_text()).get('images',[]):
  im=Image.open(p.parent/entry['filename']); assert im.mode=='RGBA'; assert im.getpixel((0,0))[3]==0
  if 'size' in entry: assert im.size==(int(entry['size'].split('x')[0])*int(entry['scale'][0]),)*2
assert len(list((R/'icons/native').glob('*.icon')))==5
assert len(list((R/'icons/legacy').glob('*.icns')))==5
print('PASS: 40 native appearance renders and every Xcode image reference.')
