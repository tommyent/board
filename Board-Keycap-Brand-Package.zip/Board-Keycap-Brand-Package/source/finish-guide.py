"""Keep editable text sources and create font-independent guide exports."""
from pathlib import Path
import html,json,re,subprocess,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parents[1]; records={}
for p in (R/'brand/guide').glob('0?.svg'):
 for node in ET.parse(p).getroot().iter('{http://www.w3.org/2000/svg}text'):
  size=float(node.attrib['font-size']); weight=int(node.attrib['font-weight']); text=node.text or ''; key=f'{weight}:{size}:{text}'
  records[key]={'key':key,'weight':weight,'size':size,'text':text}
(R/'source/guide-text.json').write_text(json.dumps(list(records.values())))
subprocess.run(['swift','-module-cache-path','/private/tmp/board-keycap-swift-cache',str(R/'source/outline-guide.swift'),str(R)],check=True)
outlined=json.loads((R/'source/guide-outlines.json').read_text()); out=R/'brand/guide/outlined'; out.mkdir(exist_ok=True)
for p in (R/'brand/guide').glob('0?.svg'):
 def replace(match):
  node=ET.fromstring(match.group()); a=node.attrib; key=f"{int(a['font-weight'])}:{float(a['font-size'])}:{node.text or ''}"
  d=outlined[key]; assert float(a['x'])+d['width']<1532,(p,node.text,d['width'])
  return f'<g transform="translate({a["x"]} {a["y"]}) scale(1 -1)" fill="{a["fill"]}" aria-label="{html.escape(node.text or "",quote=True)}">{d["paths"]}</g>'
 s=re.sub(r'<text\b[^>]*>[^<]*</text>',replace,p.read_text()); target=out/p.name; target.write_text(s)
 subprocess.run(['rsvg-convert','--width','1600','--output',str(p.with_suffix('.png')),str(target)],check=True)
subprocess.run(['rsvg-convert','--format','pdf','--output',str(R/'Board-Keycap-Brand-Guide.pdf'),str(out/'01.svg'),str(out/'02.svg'),str(out/'03.svg'),str(out/'04.svg'),str(out/'05.svg'),str(out/'06.svg')],check=True)
# Keep preview copies identical to the final, outlined guide.
import shutil
shutil.copyfile(R/'brand/guide/02.png',R/'previews/Board-Five-Colors.png'); shutil.copyfile(R/'brand/guide/05.png',R/'previews/Board-Small-Sizes.png')
print('PASS: all guide text uses Manrope outlines and fits the page bounds.')
