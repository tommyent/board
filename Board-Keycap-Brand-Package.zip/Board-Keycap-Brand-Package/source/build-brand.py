"""Build the Keycap logo extensions, palette, review sheets and six-page PDF guide."""
from pathlib import Path
import base64, html, json, os, shutil, subprocess, xml.etree.ElementTree as ET
from PIL import Image, ImageDraw, ImageFont
R=Path(__file__).resolve().parents[1]; INK='#262826'; PAPER='#FAF8F4'
COLORS={'Porcelain':('#F3EFE8','#FFFFFF','#B9B2A7',INK),'Sage':('#C8D5C5','#EAF0E7','#879D83','#27362B'),'Blue':('#C4D7E9','#E9F2FA','#839FB8','#25394A'),'Lilac':('#D9CEEB','#F2ECFC','#A495BA','#3E334B'),'Graphite':('#424743','#727970','#202421','#F3EFE8')}
APPEARANCES=['Default','Dark','ClearLight','ClearDark','TintedLight','TintedDark']
def write(p,s):
 p=R/p; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(s); return p
def svg(body,w=1024,h=1024,title='Board'):
 return f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><title>{html.escape(title)}</title>{body}</svg>'
def render(p,fmt='png',width=1600):
 p=R/p
 subprocess.run(['rsvg-convert','--format',fmt,'--width',str(width),'--output',str(p.with_suffix('.'+fmt)),str(p)],check=True,capture_output=True)
def text(x,y,s,size=24,fill=INK,weight=400):
 return f'<text x="{x}" y="{y}" font-family="Manrope" font-size="{size}" font-weight="{weight}" fill="{fill}">{html.escape(s)}</text>'
def img(p,x,y,w,h=None):
 data=base64.b64encode((R/p).read_bytes()).decode()
 return f'<image x="{x}" y="{y}" width="{w}" height="{h or w}" xlink:href="data:image/png;base64,{data}"/>'
word=json.loads((R/'source/wordmark-paths.json').read_text())['paths']
for color,(_,_,_,ink) in COLORS.items():
 s=(R/f'logos/Board-Keycap-{color}-mark.svg').read_text(); mark=s[s.index('</title>')+8:s.rindex('</svg>')]
 body=f'<g transform="translate(80 0) scale(.48)">{mark}</g><g fill="{ink}" transform="translate(84 640) scale(.82 -.82)">{word}</g>'
 p=f'logos/Board-Keycap-{color}-stacked.svg'; write(p,svg(body,650,660,'Board / '+color+' stacked logo')); render(p,width=1300); render(p,'pdf',650)
for name in ['Mono','Inverse']: render(f'logos/Board-Keycap-{name}-stacked.svg','pdf',650)
p=R/'menu-bar/BoardKeycapTemplate.svg'; p.write_text(p.read_text().replace('M3.1 13.35H14.9','M3.1 14.05H14.9'))
for scale in [1,2,3]:
 fn='BoardKeycapTemplate'+(f'@{scale}x' if scale>1 else '')+'.png'
 subprocess.run(['rsvg-convert','--width',str(18*scale),'--output',str(R/'menu-bar'/fn),str(p)],check=True)
 shutil.copyfile(R/'menu-bar'/fn,R/'menu-bar/BoardKeycapTemplate.imageset'/fn)
subprocess.run(['rsvg-convert','--format','pdf','--output',str(R/'menu-bar/BoardKeycapTemplate.pdf'),str(R/'menu-bar/BoardKeycapTemplate.svg')],check=True)
catalog=R/'Xcode/Board.xcassets'; shutil.copytree(R/'menu-bar/BoardKeycapTemplate.imageset',catalog/'BoardKeycapTemplate.imageset',dirs_exist_ok=True)
tokens={'name':'Board','identity':'Keycap','defaultIcon':'Porcelain','iconColors':{c:{'surface':v[0],'highlight':v[1],'base':v[2],'face':v[3]} for c,v in COLORS.items()},'colors':{'porcelain':'#F3EFE8','sage':'#C8D5C5','blue':'#C4D7E9','lilac':'#D9CEEB','graphite':'#424743','ink':INK,'paper':PAPER,'sage-strong':'#465C49','blue-strong':'#35566F','lilac-strong':'#625178'},'typography':{'family':'Manrope','wordmark':600,'headings':600,'body':400,'labels':500,'appUI':'macOS system font'},'spacing':[4,8,12,16,24,32,48,64],'radius':{'controls':8,'cards':16},'systemTintPreview':{'color':0.8,'strength':0.5}}
write('brand/design-tokens.json',json.dumps(tokens,indent=2)+'\n')
write('brand/board.css',':root {\n'+''.join(f'  --board-{k}: {v};\n' for k,v in tokens['colors'].items())+'  --board-font: "Manrope", sans-serif;\n}\n')
for name,color in tokens['colors'].items():
 folder=catalog/('Board'+''.join(x.title() for x in name.split('-'))+'.colorset'); folder.mkdir(exist_ok=True)
 comp={k:f'0x{color[i:i+2]}' for k,i in [('red',1),('green',3),('blue',5)]}; comp['alpha']='1.000'
 (folder/'Contents.json').write_text(json.dumps({'colors':[{'idiom':'universal','color':{'color-space':'srgb','components':comp}}],'info':{'author':'xcode','version':1}},indent=2))
font=ImageFont.truetype(str(R/'fonts/Manrope-Variable.ttf'),22)
sheet=Image.new('RGB',(1360,1510),PAPER); draw=ImageDraw.Draw(sheet)
for x,c in enumerate(COLORS):
 draw.text((40+x*264,18),c,font=font,fill=INK)
 for y,a in enumerate(APPEARANCES):
  icon=Image.open(R/f'icons/exports/{c}/Board-{c}-{a}-1024.png').convert('RGBA').resize((210,210),Image.Resampling.LANCZOS)
  xy=(40+x*264,65+y*238); sheet.paste(icon,xy,icon); draw.text((xy[0],xy[1]+212),a,font=font,fill=INK)
sheet.save(R/'previews/Board-Native-Appearances.jpg',quality=94)
pages=[]
def page(n,title,sub,body):
 head=f'<rect width="1600" height="1000" fill="{PAPER}"/>'+text(70,58,'BOARD / KEYCAP IDENTITY',16,INK,600)+text(1430,58,f'0{n} / 06',16)
 head+=text(70,144,title,56,INK,600)+text(70,192,sub,23)
 foot='<path d="M70 932H1530" stroke="#DEDAD2"/>'+text(70,967,'Board  /  Brand guidelines & production assets',16)+text(1340,967,'OCTOBER 2026',16)
 p=f'brand/guide/0{n}.svg'; write(p,svg(head+body+foot,1600,1000,'Board brand guide / '+title)); render(p); pages.append(p)
body=img('icons/exports/Porcelain/Board-Porcelain-Default-1024.png',880,248,560)+img('logos/Board-Keycap-Mono-horizontal.png',50,277,740,231)
body+=text(70,572,'A familiar key. A friendly face.',36,INK,600)+text(70,634,'Soft physical detail for the Mac app icon.',25)+text(70,675,'Flat geometry for logos and everyday branding.',25)
body+=text(70,760,'SIGNATURE',16,INK,600)+text(70,803,'Keycap / Porcelain / Ink / Manrope 600',25)+text(70,870,'Five colors. One recognizable character.',25,INK,500)
page(1,'Meet Board','A warm, practical identity built around your selected Keycap.',body)
body=''
for i,(c,(mid,hi,base,ink)) in enumerate(COLORS.items()):
 x=70+i*298; body+=img(f'icons/exports/{c}/Board-{c}-Default-1024.png',x,255,265)+text(x,568,c,27,INK,600)
 body+=f'<rect x="{x}" y="600" width="265" height="60" rx="14" fill="{mid}" stroke="#DAD6CF"/>'+text(x,697,mid,23)+text(x,741,'Face '+ink,18)+text(x,777,'Base '+base,18)
body+=text(70,862,'Porcelain is the starting color. Let people choose any of the five in Board.',25,INK,500)
page(2,'Five colors. Their choice.','One native Icon Composer master per color. Shared geometry and material settings.',body)
body=img('logos/Board-Keycap-Porcelain-horizontal.png',50,252,680,212)+img('logos/Board-Keycap-Mono-horizontal.png',50,494,680,212)
body+='<rect x="810" y="245" width="720" height="270" rx="24" fill="'+INK+'"/>'+img('logos/Board-Keycap-Inverse-horizontal.png',830,263,680,212)+img('logos/Board-Keycap-Porcelain-stacked.png',1000,550,260,264)
body+=text(70,775,'Clear space: at least one eye diameter.',24,INK,500)+text(70,819,'Minimums: horizontal 120 px; standalone mark 24 px.',22)+text(70,860,'Use Ink on light surfaces and the inverse logo on dark surfaces.',22)
page(3,'A logo for every surface','Mark, horizontal, stacked and standalone wordmark. SVG, PNG and vector PDF.',body)
body=text(70,275,'MANROPE / INCLUDED WITH OFL LICENSE',18,INK,600)+text(70,377,'Board',94,INK,600)+text(70,457,'Friendly. Clear. Quietly useful.',34,INK,500)
for y,line in [(530,'600 / Wordmark and brand headings'),(575,'500 / Labels and short captions'),(620,'400 / Body copy'),(710,'Use the macOS system font in the app UI.'),(755,'Outlined logos keep their shape without a font install.')]: body+=text(70,y,line,24)
body+=text(940,285,'VOICE',18,INK,600)+text(940,345,'Calm. Direct. Helpful.',30,INK,600)
for y,line in [(405,'Use short, concrete sentences.'),(447,'Name the action clearly.'),(489,'Keep the personality in the character.'),(580,'Open Board'),(625,'Choose your icon color'),(670,'Saved')]: body+=text(940,y,line,24)
body+=text(70,869,'Spacing: 4 / 8 / 12 / 16 / 24 / 32 / 48 / 64. Keep corners softly rounded.',24)
page(4,'Soft shapes. Clear words.','A single brand typeface, native interface typography and a straightforward voice.',body)
body=text(70,266,'MENU BAR / 18 PT TEMPLATE',18,INK,600)
menutext=(R/'menu-bar/BoardKeycapTemplate.svg').read_text(); menubody=menutext[menutext.index('<rect'):menutext.rindex('</svg>')]
for x,bg,fg in [(70,'#E6E3DE','black'),(470,INK,'#F3EFE8')]:
 body+=f'<rect x="{x}" y="300" width="350" height="100" rx="20" fill="{bg}"/>'
 body+=f'<g transform="translate({x+50} 341)">{menubody.replace("black",fg)}</g><g transform="translate({x+130} 332) scale(2)">{menubody.replace("black",fg)}</g><g transform="translate({x+240} 314) scale(4)">{menubody.replace("black",fg)}</g>'
body+=text(70,459,'One template for every icon color.',25,INK,500)+text(70,500,'The system supplies menu bar tint.',23)+text(70,589,'DOCK / PIXEL SIZES',18,INK,600)
for size,x in [(16,70),(32,150),(64,260),(128,420),(256,650)]:
 fn={16:'icon_16x16.png',32:'icon_16x16@2x.png',64:'icon_32x32@2x.png',128:'icon_128x128.png',256:'icon_128x128@2x.png'}[size]
 body+=img('icons/legacy/Board-Porcelain.iconset/'+fn,x,638,size)+text(x,914,str(size),16)
body+=text(1030,310,'KEEP IT RECOGNIZABLE',18,INK,600)
for y,line in [(370,'Keep eye spacing and smile shape.'),(420,'Keep the lower keycap edge.'),(470,'Use the template at menu sizes.'),(520,'Avoid stretching or recoloring faces.'),(610,'Small native rasters come from'),(650,"Apple's asset compiler."),(730,'Flat logos are a separate asset;'),(770,'do not use the shaded app icon'),(810,'as a replacement for the wordmark.')]: body+=text(1030,y,line,22)
page(5,'Small, still Board','Dedicated menu template plus native small-size app icon exports.',body)
body=''
for i,c in enumerate(COLORS):
 x=70+i*290; body+=img(f'icons/exports/{c}/Board-{c}-Dark-1024.png',x,252,200)+text(x,490,c,23,INK,600)
for y,heading,desc in [(557,'Native masters','Five .icon documents with Default, Dark and Mono styling.'),(653,'Xcode handoff','BoardPorcelain is the default. All five colors have Dock assets and picker previews.'),(749,'Runtime color selection','The AppKit handoff helper is designed to save and reapply the chosen Dock color.')]: body+=text(70,y,heading,26,INK,600)+text(70,y+41,desc,23)
body+=text(70,845,'App integration is still required. Dock overrides leave the packaged primary intact.',23)+text(70,886,'Clear and tinted previews are system appearances; they are not extra brand colors.',20)
page(6,'Ready for the Mac','Editable native sources, compatible exports and a documented path to color choice.',body)
subprocess.run(['rsvg-convert','--format','pdf','--output',str(R/'Board-Keycap-Brand-Guide.pdf'),str(R/'brand/guide/01.svg'),str(R/'brand/guide/02.svg'),str(R/'brand/guide/03.svg'),str(R/'brand/guide/04.svg'),str(R/'brand/guide/05.svg'),str(R/'brand/guide/06.svg')],check=True,capture_output=True)
shutil.copyfile(R/'brand/guide/02.png',R/'previews/Board-Five-Colors.png'); shutil.copyfile(R/'brand/guide/05.png',R/'previews/Board-Small-Sizes.png')
for p in R.rglob('*.svg'): ET.parse(p)
assert len(pages)==6
assert 'SIL OPEN FONT LICENSE' in (R/'fonts/OFL-Manrope.txt').read_text()
print('PASS: SVG sources, font license, colored stacked logos, menu and six guide pages.')

subprocess.run(['python3',str(R/'source/finish-guide.py')],check=True)
