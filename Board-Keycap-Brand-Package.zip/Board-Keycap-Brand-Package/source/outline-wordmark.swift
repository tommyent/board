import Foundation
import CoreText
import CoreGraphics

let root = URL(fileURLWithPath: CommandLine.arguments[1])
let fontURL = root.appendingPathComponent("fonts/Manrope-Variable.ttf")
var error: Unmanaged<CFError>?
precondition(CTFontManagerRegisterFontsForURL(fontURL as CFURL, .process, &error))
let descriptors = CTFontManagerCreateFontDescriptorsFromURL(fontURL as CFURL) as! [CTFontDescriptor]
let descriptor = CTFontDescriptorCreateCopyWithAttributes(descriptors[0], [kCTFontVariationAttribute: [NSNumber(value: 0x77676874): 600]] as CFDictionary)
let font = CTFontCreateWithFontDescriptor(descriptor, 220, nil)
precondition((CTFontCopyFamilyName(font) as String) == "Manrope")
let attributed = NSAttributedString(string: "Board", attributes: [NSAttributedString.Key(kCTFontAttributeName as String): font, NSAttributedString.Key(kCTKernAttributeName as String): -5])
let line = CTLineCreateWithAttributedString(attributed)
var paths = ""
var glyphCount = 0
func num(_ n: CGFloat) -> String { String(format: "%.3f", Double(n)) }
for run in CTLineGetGlyphRuns(line) as! [CTRun] {
    let count = CTRunGetGlyphCount(run)
    var glyphs = [CGGlyph](repeating: 0, count: count)
    var positions = [CGPoint](repeating: .zero, count: count)
    CTRunGetGlyphs(run, CFRange(location: 0, length: 0), &glyphs)
    CTRunGetPositions(run, CFRange(location: 0, length: 0), &positions)
    for i in 0..<count {
        let path = CTFontCreatePathForGlyph(font, glyphs[i], nil)!
        var data = ""
        path.applyWithBlock { element in
            let e = element.pointee
            func point(_ j: Int) -> String { "\(num(e.points[j].x + positions[i].x)) \(num(e.points[j].y))" }
            switch e.type {
            case .moveToPoint: data += "M\(point(0)) "
            case .addLineToPoint: data += "L\(point(0)) "
            case .addQuadCurveToPoint: data += "Q\(point(0)) \(point(1)) "
            case .addCurveToPoint: data += "C\(point(0)) \(point(1)) \(point(2)) "
            case .closeSubpath: data += "Z "
            @unknown default: fatalError("Unknown path element")
            }
        }
        paths += "<path d=\"\(data)\"/>\n"
        glyphCount += 1
    }
}
precondition(glyphCount == 5)
let width = CTLineGetTypographicBounds(line, nil, nil, nil)
let output: [String: Any] = ["width": width, "paths": paths, "family": CTFontCopyFamilyName(font) as String, "weight": 600]
let data = try JSONSerialization.data(withJSONObject: output, options: [.prettyPrinted, .sortedKeys])
try data.write(to: root.appendingPathComponent("source/wordmark-paths.json"))
print("Outlined five Manrope glyphs at weight 600; width \(width)")
