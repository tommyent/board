import Foundation
import CoreText
import CoreGraphics

let root = URL(fileURLWithPath: CommandLine.arguments[1])
var error: Unmanaged<CFError>?
precondition(CTFontManagerRegisterFontsForURL(root.appendingPathComponent("fonts/Manrope-Variable.ttf") as CFURL, .process, &error))
let descriptors = CTFontManagerCreateFontDescriptorsFromURL(root.appendingPathComponent("fonts/Manrope-Variable.ttf") as CFURL) as! [CTFontDescriptor]
let records = try JSONSerialization.jsonObject(with: Data(contentsOf: root.appendingPathComponent("source/guide-text.json"))) as! [[String: Any]]
var result: [String: Any] = [:]
func num(_ n: CGFloat) -> String { String(format: "%.3f", Double(n)) }
for record in records {
    let weight = record["weight"] as! Int
    let size = record["size"] as! Double
    let text = record["text"] as! String
    let key = record["key"] as! String
    let descriptor = CTFontDescriptorCreateCopyWithAttributes(descriptors[0], [kCTFontVariationAttribute: [NSNumber(value: 0x77676874): weight]] as CFDictionary)
    let font = CTFontCreateWithFontDescriptor(descriptor, size, nil)
    precondition((CTFontCopyFamilyName(font) as String) == "Manrope")
    let line = CTLineCreateWithAttributedString(NSAttributedString(string: text, attributes: [NSAttributedString.Key(kCTFontAttributeName as String): font]))
    var paths = ""
    for run in CTLineGetGlyphRuns(line) as! [CTRun] {
        let count = CTRunGetGlyphCount(run)
        var glyphs = [CGGlyph](repeating: 0, count: count)
        var positions = [CGPoint](repeating: .zero, count: count)
        CTRunGetGlyphs(run, CFRange(location: 0, length: 0), &glyphs)
        CTRunGetPositions(run, CFRange(location: 0, length: 0), &positions)
        for i in 0..<count {
            guard let path = CTFontCreatePathForGlyph(font, glyphs[i], nil) else { continue }
            var data = ""
            path.applyWithBlock { element in
                let e = element.pointee
                func point(_ j: Int) -> String { "\(num(e.points[j].x + positions[i].x)) \(num(e.points[j].y))" }
                switch e.type {
                case .moveToPoint: data += "M\(point(0)) "
                case .addLineToPoint: data += "L\(point(0)) "
                case .addQuadCurveToPoint: data += "Q\(point(0)) \(point(1)) "
                case .addCurveToPoint: data += "C\(point(0)) \(point(1)) \(point(2)) "
                case .closeSubpath: data += "Z "
                @unknown default: fatalError("Unknown path element")
                }
            }
            paths += "<path d=\"\(data)\"/>"
        }
    }
    result[key] = ["paths": paths, "width": CTLineGetTypographicBounds(line, nil, nil, nil)]
}
try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys]).write(to: root.appendingPathComponent("source/guide-outlines.json"))
print("Outlined \(result.count) Manrope text runs with verified font identity.")
