import AppKit

public enum BoardIconColor: String, CaseIterable {
    case porcelain = "Porcelain"
    case sage = "Sage"
    case blue = "Blue"
    case lilac = "Lilac"
    case graphite = "Graphite"

    public var previewAssetName: String { "BoardIcon\(rawValue)" }
}

@MainActor
public enum BoardIconSelection {
    private static let preferenceKey = "Board.iconColor"

    public static func current(in defaults: UserDefaults = .standard) -> BoardIconColor {
        BoardIconColor(rawValue: defaults.string(forKey: preferenceKey) ?? "") ?? .porcelain
    }

    public static func apply(
        _ color: BoardIconColor,
        bundle: Bundle = .main,
        defaults: UserDefaults = .standard
    ) throws {
        let image: NSImage?
        if color == .porcelain {
            // Restore the native bundled icon, including its system appearances.
            image = nil
        } else {
            guard let url = bundle.url(
                forResource: "Board-\(color.rawValue)",
                withExtension: "icns",
                subdirectory: "BoardDockIcons"
            ), let loaded = NSImage(contentsOf: url), loaded.isValid else {
                throw CocoaError(.fileReadCorruptFile)
            }
            image = loaded
        }
        // shortcut: Alternate Dock icons are static; add appearance-aware loading if needed.
        NSApplication.shared.applicationIconImage = image
        defaults.set(color.rawValue, forKey: preferenceKey)
    }

    public static func restore(
        bundle: Bundle = .main,
        defaults: UserDefaults = .standard
    ) throws {
        try apply(current(in: defaults), bundle: bundle, defaults: defaults)
    }
}
