# Board macOS branding handoff

## Primary app icon

Use `icons/native/BoardPorcelain.icon` as Board's primary app icon. The verified asset compiler name is `BoardPorcelain`, corresponding to build setting `ASSETCATALOG_COMPILER_APPICON_NAME = BoardPorcelain`. The five `.icon` documents can be included alongside `Xcode/Board.xcassets`; this exact combination compiles successfully with Xcode 27.0's `actool`, platform `macosx`, minimum deployment target `13.0`.

Native `.icon` compilation produces the primary ICNS and `Assets.car`. Preserve the complete build output; the ICNS alone does not contain the native appearance system. Keep the `.icon` sources as source files and let Xcode compile them.

For an older toolchain that cannot compile `.icon`, `LegacyAppIcons.xcassets` provides five classic app icon sets. Their names are `BoardPorcelainLegacy`, `BoardSageLegacy`, `BoardBlueLegacy`, `BoardLilacLegacy` and `BoardGraphiteLegacy`. Choose the intended default name as the app icon build setting. These are static fallback assets.

## Let users choose a color

`BoardIconSelection.swift` is a small AppKit handoff component. Include the `BoardDockIcons` folder as a bundled resource directory, preserving its folder name and five ICNS filenames. All choices use the enum `BoardIconColor`; do not construct filenames from user-entered text.

The helper exposes:

- `BoardIconSelection.current()` to read the saved color, defaulting to Porcelain.
- `try BoardIconSelection.apply(.sage)` to apply a choice and persist it only after its resource loads.
- `try BoardIconSelection.restore()` to reapply the choice during application startup.

Calls run on the main actor. Handle thrown resource errors in the app and preserve the previous picker state if an apply fails. Call `restore` after the application has launched. By code inspection, Porcelain sets `applicationIconImage` to `nil` to request the native bundled icon, and other choices load the corresponding full ICNS. This path has not been exercised in a running Board app.

Apple documents `applicationIconImage` as a temporary override of the running application’s Dock tile. The helper is designed to use this API without modifying the app bundle, its signature or Finder’s packaged primary. The helper's alternate icons are static Default artwork; matching clear, dark or tinted system appearance at runtime would need an appearance-aware integration in the app. Separate native masters and all six appearance PNGs are supplied for that work.

## Picker and menu assets

The main catalog includes these preview names: `BoardIconPorcelain`, `BoardIconSage`, `BoardIconBlue`, `BoardIconLilac`, `BoardIconGraphite`. Present five labeled choices, expose the selected state, support keyboard selection, and use a checkmark or selection ring as well as color. Keep the names Porcelain, Sage, Blue, Lilac and Graphite visible. The menu bar icon stays the same for every choice.

`BoardKeycapTemplate` is marked Template in the catalog. For direct PDF loading, use an 18 x 18 point `NSImage` with `isTemplate = true`. The system supplies its tint.

The catalog also includes `BoardPorcelain`, `BoardSage`, `BoardBlue`, `BoardLilac`, `BoardGraphite`, `BoardInk`, `BoardPaper`, `BoardSageStrong`, `BoardBlueStrong` and `BoardLilacStrong` named colors. Brand typography is Manrope; app typography should use the macOS system font.

## Verification boundary

All five masters were opened in Icon Composer. Each native document compiles individually. The combined native sources and main catalog compile together. Five full ICNS files decode to ten sizes; AppKit loads their 1024-pixel representations. The 18-point template loads in AppKit, and the helper passes Swift typechecking. No existing Board app was supplied, so startup persistence, Dock switching and a live menu bar were not exercised inside Board.

Official references: [Apple's Icon Composer workflow](https://developer.apple.com/documentation/xcode/creating-your-app-icon-using-icon-composer), [applicationIconImage](https://developer.apple.com/documentation/appkit/nsapplication/applicationiconimage), [Icon Composer](https://developer.apple.com/icon-composer/).
