# Board - Keycap brand package

Board's selected identity is the smiling Keycap. The signature is Porcelain with Ink lettering and Manrope SemiBold. Five finishes are supplied for an app color picker: Porcelain, Sage, Blue, Lilac and Graphite.

Open `Board-Gallery.html` for the color explorer, downloads, logo previews and font samples. `Board-Keycap-Brand-Guide.pdf` is the six-page visual guide. Editable guide text is in `brand/guide`; outlined, font-independent copies are in `brand/guide/outlined`.

## Native app icons

`icons/native` contains five real Icon Composer documents: `BoardPorcelain.icon`, `BoardSage.icon`, `BoardBlue.icon`, `BoardLilac.icon` and `BoardGraphite.icon`. Open them in Icon Composer. Each contains its SVG assets, an opaque expression group, a native glass keycap surface, and a native background. The SVGs contain no baked outer mask or shadow.

The native sources have Default, Dark and Mono styling. Mono uses system light/dark fills for a consistent simplified face across all colors. The renderer supplies clear and tinted appearances from this styling. The six appearance PNGs are exports from Apple's bundled `ictool`, using design generation 27. Default and Dark have 1024 and 2048 pixel exports. Tinted examples use one explicit sample tint (color 0.8, strength 0.5); users' system tints can look different. They are not extra brand colors.

`icons/legacy` contains five full `.icns` files and ten-size `.iconset` folders. Small rasters come from Apple's native `actool` output. Larger rasters fit the native Composer export into the observed 80% legacy metrics. The `Dock-1024` PNGs use these legacy insets; the regular native PNG exports are full canvas. Use Dock files for a direct `NSImage` icon replacement.

## Logos and digital assets

`logos` includes marks, horizontal lockups and stacked lockups in all five colors, plus Mono and Inverse versions. Formats: SVG, transparent PNG and vector PDF. `logos/Wordmark` contains standalone outlined Board wordmarks. All wordmarks are Manrope 600 outlines, with deliberate tight spacing; no font installation is required to use the logo.

Use the Ink logo on light backgrounds. Use Inverse on dark backgrounds. Graphite's color logo has light lettering and belongs on a dark background. Keep at least one eye diameter of clear space. Minimum horizontal logo width: 120 px; standalone brand mark: 24 px. Use the dedicated menu glyph below those sizes. Keep the eye spacing, smile and lower keycap edge unchanged.

`digital` includes 32, 64, 180 and 512 pixel identity images in all five colors for favicons, avatars and small web placements.

## Menu bar

`menu-bar` includes an 18-point vector PDF, editable SVG, PNGs at 18/36/54 pixels, and a Template imageset. Use the same monochrome glyph for every app color. The Xcode imageset is marked for template rendering. If loading the PDF directly into an `NSImage`, set `isTemplate = true` and its size to 18 x 18 points.

## Typography, color and voice

Manrope variable font and its SIL Open Font License are included in `fonts`. Use 600 for brand headings, 500 for labels and 400 for body copy. Use the native macOS system font for app interface controls and text.

| Finish | Surface | Face | Base |
| --- | --- | --- | --- |
| Porcelain | #F3EFE8 | #262826 | #B9B2A7 |
| Sage | #C8D5C5 | #27362B | #879D83 |
| Blue | #C4D7E9 | #25394A | #839FB8 |
| Lilac | #D9CEEB | #3E334B | #A495BA |
| Graphite | #424743 | #F3EFE8 | #202421 |

Use Paper (#FAF8F4) for brand backgrounds and Ink (#262826) for normal text. Pale finish colors are surfaces; use the included stronger accents for colored text or controls. Exact values, highlights, spacing and font weights are in `brand/design-tokens.json`, `brand/board.css` and the named Xcode color assets. Color choices must also have text labels and a selected indicator.

Board's voice is calm, direct and helpful. Use short concrete sentences and clear actions: "Open Board", "Choose your icon color", "Saved". Keep the personality in the character.

## macOS integration and verification

See `Xcode/HANDOFF.md` for the primary icon, selectable Dock resources, named asset catalog, legacy catalog and AppKit helper. The package's native documents and complete catalog compile in Xcode's asset compiler. Every full ICNS passes roundtrip decoding, and AppKit loads the five 1024-pixel resources and 18-point menu PDF. The helper typechecks. All six final PDF pages were rendered and reviewed. See `brand/VERIFICATION.md` for exact coverage and limits.

The helper is a handoff component, not an integration into an existing Board app. The helper is intended to use AppKit’s temporary Dock icon override; Finder and the packaged primary are outside that mechanism. Alternate helper icons are static Default renderings. The intended Porcelain reset returns control to the native primary and its system appearances.

## Rebuilding

Requirements: macOS, Xcode with Icon Composer, Python 3 with Pillow, Swift, `rsvg-convert` and `iconutil`. The script's two Apple tool paths target the installed Xcode-beta bundle; adjust those paths if Xcode is installed under a different name. No tools are installed and no app project is modified by these scripts.

From this package folder, run `python3 source/build-exports.py`, then `python3 source/build-brand.py`, then `python3 source/assemble-gallery.py`. Brand building outlines text through CoreText using the bundled font, so exported guide typography is independent of installed fonts. Build scratch files remain in the temporary folder. Native `.icon` documents and existing logo SVGs are the editable masters; preserve changes there before rebuilding.
