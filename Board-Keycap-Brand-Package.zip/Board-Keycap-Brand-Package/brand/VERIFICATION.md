# Board package verification

Verified on 11 October 2026 with Icon Composer 2.0 (125) and Xcode 27.0.

- Five native `.icon` documents opened in Icon Composer; SVG layers and native keycap surface are present.
- Each native document compiled with Apple's `actool` for macOS, minimum deployment target 13.0.
- All five native documents compiled together with the final `Board.xcassets`; result includes `Assets.car`, `BoardPorcelain.icns` and primary-icon metadata.
- Forty native appearance exports generated with Apple's `ictool`: Default and Dark at 1024/2048, plus ClearLight, ClearDark, TintedLight and TintedDark at 1024 for each color. All were checked for dimensions and alpha.
- Five full ICNS files roundtrip through `iconutil` to ten named raster sizes each. Small rasters use Apple's compiled output; larger sizes use native exports fitted to legacy metrics.
- AppKit loaded all five ICNS resources, found 1024-pixel representations, and loaded the menu PDF at exactly 18 x 18 points. The template flag was set and checked in AppKit.
- `BoardIconSelection.swift` passed Swift typechecking. Code inspection indicates preferences are written after resource loading and the default requests the native primary; runtime switching and persistence were not tested.
- Every Xcode image reference exists. Image dimensions, SVG XML and font license were checked.
- Six final guide pages were rendered from the PDF and visually inspected. Every guide text run was outlined through CoreText with its font family verified as Manrope; width checks confirm page bounds. Editable text sources remain separate.
- Gallery local links and all dynamic color/appearance paths were checked. Its controls use native HTML radio inputs.

The visual review refined Mono styling across all five finishes and separated the menu glyph's smile from its lower edge. Clear and tinted appearances are system-controlled; the supplied tint images illustrate one explicit sample and are not a guarantee of contrast at every user-selected system tint.

Not exercised: integration into a Board app, live startup restoration, real Dock color changes, live menu bar presentation, or interactive gallery use in a browser. No existing app project was supplied or modified. The alternate-color helper uses static Default icons; the native primary retains system appearance adaptation. The package does not change Finder icons at runtime.
